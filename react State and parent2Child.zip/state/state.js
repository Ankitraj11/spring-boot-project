class Welcome extends React.Component{

    state={
        uname:"Ajay",
        age:20
    }

    render(){
        return <div>
            <h1>Welcome , {this.state.uname} age:{this.state.age} </h1>
            <button onClick={()=>{this.ChangeName()}}>Change Name</button>
        </div>
    }

    ChangeName(){
        // Never update state like this
        // this.state.uname="vijay"
        this.setState({
            uname:"Vijay",
            age:40
        },()=>{
            console.log(this.state);
        })
        
    }
}

ReactDOM.render(<Welcome />,document.getElementById("container"))