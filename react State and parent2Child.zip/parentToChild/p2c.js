class Parent extends React.Component{
    render(){
        let data = "hello from parent"
        let data2 = "hello child 2"
        return <div>
            <h1>i m parent </h1>
            <p>user name is {this.props.user}</p>
            <Child data={data} />
            <Child2 hello={data2} />
            </div>
    }
}

class Child extends React.Component{
    render(){
        return <div>
            <h1>i m child {this.props.data}</h1>
        </div>
    }
}

class Child2 extends React.Component{
    render(){
        return <div>
            <h1>i m child2</h1>
            <p>{this.props.hello}</p>
        </div>
    }
}

ReactDOM.render(<Parent user="Ajay" />, document.getElementById("container"))