package com.te.springdatajpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.te.springdatajpa.bean.Student;
import com.te.springdatajpa.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	private StudentService service;

	@GetMapping("/student/{id}")
	public ResponseEntity<?> getData(@PathVariable int id) {

		Student student = service.getData(id);
		if (student != null)
			return new ResponseEntity<Student>(student, HttpStatus.OK);
		else
			return new ResponseEntity<String>("data not found for id:" + id, HttpStatus.INTERNAL_SERVER_ERROR);

	}
	@PostMapping("/student")
	public ResponseEntity<?> addData(@RequestBody Student student) {
		try {
			service.addData(student);
			return new ResponseEntity<String>("Data added Successfully", HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>("Somthing went Wrong!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	@DeleteMapping("/student/{id}")
	public ResponseEntity<?> deleteData(@PathVariable int id) {
		try {
			service.deleteData(id);
			return new ResponseEntity<String>("Data deleted Successfully", HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>("Data Not Foung!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
	@PutMapping("/student")
	public ResponseEntity<?> updateData(@RequestBody Student student) {
		service.updateData(student);
		return new ResponseEntity<String>("Data updated Successfully", HttpStatus.OK);
	}
	@GetMapping("/getstudent")
	public List<Student> selectAll(){
		List<Student> students = service.selectAll();
		return students;
	}

}
