package com.te.springdatajpa.dao;

import org.springframework.data.repository.CrudRepository;

import com.te.springdatajpa.bean.Student;

public interface StudentDao extends CrudRepository<Student, Integer>{
	
	public Student  findByStuId(int id);

}
