package com.te.springdatajpa.service;


import java.util.List;

import com.te.springdatajpa.bean.Student;
public interface StudentService {
	Student getData(int id);
	Student addData(Student student);
	void deleteData(int id);
	Student updateData(Student student);
	List<Student> selectAll();

}
