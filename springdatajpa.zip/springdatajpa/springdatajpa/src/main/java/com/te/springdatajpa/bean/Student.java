package com.te.springdatajpa.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Student implements Serializable {
	@Id
	private int stuId;
	private String stuName;
	private Date dob;
	private String password;

}
