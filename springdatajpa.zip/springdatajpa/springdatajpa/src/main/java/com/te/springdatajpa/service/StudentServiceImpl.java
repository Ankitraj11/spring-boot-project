package com.te.springdatajpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.springdatajpa.bean.Student;
import com.te.springdatajpa.dao.StudentDao;

@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDao dao;

	@Override
	public Student getData(int id) {
		return dao.findByStuId(id);
	}

	@Override
	public Student addData(Student student) {
		return dao.save(student);
	}

	@Override
	public void deleteData(int id) {
		Student student = dao.findByStuId(id);
		dao.delete(student);
		
	}

	@Override
	public Student updateData(Student student) {
		return dao.save(student);
	}

	@Override
	public List<Student> selectAll() {
		return (List<Student>) dao.findAll();
	}

}
