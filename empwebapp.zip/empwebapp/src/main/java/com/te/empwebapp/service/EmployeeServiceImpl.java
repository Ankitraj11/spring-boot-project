package com.te.empwebapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.empwebapp.bean.EmployeeDetails;
import com.te.empwebapp.dao.EmployeeDao;
import com.te.empwebapp.dao.EmployeeDaoImpl;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao dao;

	@Override
	public EmployeeDetails authenticate(int id, String password) {
		if (id <= 0) {
			return null;
		}
		return dao.authenticate(id, password);

	}

	@Override
	public boolean addData(EmployeeDetails details) {
		return dao.addData(details);
	}

	@Override
	public boolean deleteData(int id) {
		if (id <= 0) {
			return false;
		}
		return dao.deleteData(id);
	}

	@Override
	public EmployeeDetails getData(int id) {
		if (id <= 0) {
			return null;
		} else {
			return dao.getData(id);
		}
	}

	@Override
	public boolean updateData(EmployeeDetails details, int id) {
		return dao.updateData(details, id);
	}
}
