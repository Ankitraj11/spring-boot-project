package com.te.empwebapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;

import org.springframework.stereotype.Repository;

import com.te.empwebapp.bean.EmployeeDetails;
import com.te.empwebapp.exception.EmployeeException;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@PersistenceUnit
	private EntityManagerFactory factory;

	@Override
	public EmployeeDetails authenticate(int id, String password) {
//		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
		EntityManager manager = factory.createEntityManager();
		EmployeeDetails details = manager.find(EmployeeDetails.class, id);
		if (details != null) {
			if (details.getPassword().equals(password)) {
				return details;
			} else {
				throw new EmployeeException("Invalid password");
			}
		}
		throw new EmployeeException("Invalid ID");
	}

	@Override
	public boolean addData(EmployeeDetails details) {
		boolean isAdded = false;
		EntityTransaction transaction = null;
		try {
//			EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
			EntityManager manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			manager.persist(details);
			transaction.commit();
			isAdded = true;
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return isAdded;
	}

	@Override
	public boolean deleteData(int id) {
		boolean isDeleted = false;
		EntityTransaction transaction = null;
		try {
//			EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
			EntityManager manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			EmployeeDetails details = manager.find(EmployeeDetails.class, id);
			manager.remove(details);
			transaction.commit();
			isDeleted = true;
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return isDeleted;
	}

	@Override
	public EmployeeDetails getData(int id) {
//		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
		EntityManager manager = factory.createEntityManager();
		EmployeeDetails details = manager.find(EmployeeDetails.class, id);
		if (details != null) {
			return details;
		}
		return null;
	}

	@Override
	public boolean updateData(EmployeeDetails details, int id) {
		boolean isUpdated = false;
		EntityTransaction transaction = null;
		try {
//			EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
			EntityManager manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			EmployeeDetails details2 = manager.find(EmployeeDetails.class, id);
			if (details2 != null) {
				details2.setName(details.getName());
				details2.setAddress(details.getAddress());
				details2.setPassword(details.getPassword());
			}
			manager.persist(details2);
			transaction.commit();
			isUpdated = true;
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return isUpdated;
	}
}
