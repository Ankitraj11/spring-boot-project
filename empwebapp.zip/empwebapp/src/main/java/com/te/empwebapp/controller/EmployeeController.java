package com.te.empwebapp.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.sun.tools.classfile.Annotation.element_value;
import com.te.empwebapp.bean.EmployeeDetails;
import com.te.empwebapp.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@GetMapping("/login")
	public String login() {
		return "loginform";
	}

	@PostMapping("/login")
	public String authenticate(int id, String password, ModelMap map, HttpServletRequest request) {
		EmployeeDetails details = service.authenticate(id, password);
		HttpSession session = request.getSession();
		session.setAttribute("loggedIn", details);
		if (details != null) {
			map.addAttribute("data", details.getName());
			return "welcome";
		} else {
			map.addAttribute("errMsg", "Invalid Credentials");
			return "loginform";
		}
	}

	@GetMapping("/add")
	public String addForm(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details,
			ModelMap map) {
		if (details != null) {
			return "addForm";
		} else {
			map.addAttribute("errMsg", "Please login first");
			return "loginform";
		}
	}

	@PostMapping("/add")
	public String addData(EmployeeDetails details, ModelMap map,
			@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details2) {
		if (details2 != null) {
			if (service.addData(details)) {
				map.addAttribute("msg", "Data inserted succesfully!");
			} else {
				map.addAttribute("errMsg", "Something went wrong!");
			}
			return "addForm";
		} else {
			map.addAttribute("errMsg", "Please login first");
			return "loginform";
		}

	}

	@GetMapping("/delete")
	public String deleteForm(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details,
			ModelMap map) {
		if (details != null) {
			return "deleteForm";
		} else {
			map.addAttribute("errMsg", "Please login first");
			return "loginform";
		}
	}

	@PostMapping("/delete")
	public String deleteData(ModelMap map, int id,
			@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details) {
		if (details != null) {
			if (service.deleteData(id)) {
				map.addAttribute("msg", "Data deleted successfully");
			} else {
				map.addAttribute("msg", "Data not found for id:" + id);
			}
			return "deleteForm";

		} else {
			map.addAttribute("errMsg", "Please login first");
			return "loginform";
		}
	}

	@GetMapping("/getData")
	public String getForm(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details,
			ModelMap map) {
		if (details != null) {
			return "getForm";
		} else {

			map.addAttribute("errMsg", "Please login first");
			return "loginform";
		}

	}

	@PostMapping("/getData")
	public String getData(int id, ModelMap map,
			@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details) {
		if (details != null) {
			EmployeeDetails details2 = service.getData(id);
			if (details2 != null) {
				map.addAttribute("data", details2);
			} else {
				map.addAttribute("msg", "Data not found for id:" + id);
			}
			return "getForm";
		} else {
			map.addAttribute("errMsg", "Please login first");
			return "loginform";
		}
	}

	@GetMapping("/update")
	public String updateForm(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details,
			ModelMap map) {
		if (details != null) {
			map.addAttribute("data", details.getId());
			return "updateForm";
		} else {
			map.addAttribute("errMsg", "Please login first");
			return "loginform";
		}
	}

	@PostMapping("/update")
	public String updateData(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details,
			EmployeeDetails details2, ModelMap map) {
		if (details != null) {
			if (service.updateData(details2, details.getId())) {
				map.addAttribute("msg", "Data updated successfully");
			} else {
				map.addAttribute("msg", "Something went wrong");
			}
			return "updateForm";
		} else {
			map.addAttribute("errMsg", "Please login first");
			return "loginform";
		}
	}

	@GetMapping("/logout")
	public String logout(ModelMap map, HttpSession session) {
		map.addAttribute("errMsg", "Logged out Successfully");
		session.invalidate();
		return "loginform";
	}

}
