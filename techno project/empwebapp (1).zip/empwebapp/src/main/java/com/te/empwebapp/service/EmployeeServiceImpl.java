package com.te.empwebapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.te.empwebapp.bean.EmployeeDetails;
import com.te.empwebapp.dao.EmployeeDao;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDao dao;

	@Override
	public EmployeeDetails authenticate(int id, String name) {
		if (id <= 0) {
			return null;
		}
		return dao.authenticate(id, name);
	}

	@Override
	public boolean addData(EmployeeDetails details) {

		return dao.addData(details);
	}

	@Override
	public boolean deleteData(int id) {
		if (id <= 0) {
			return false;
		}
		return dao.deleteData(id);
	}

	@Override
	public EmployeeDetails showData(int id) {
		if (id <= 0) {
			return null;
		}
		return dao.showData(id);
	}

	@Override
	public List<EmployeeDetails> showDataAll() {
		return dao.showDataAll();
	}

	@Override
	public EmployeeDetails updateemp(EmployeeDetails details,EmployeeDetails details2 ) {
			return dao.updateemp(details,details2);
	}

//	@Override
//	public boolean updateallemp(String name, String address, String password, String id) {
//		if (!id.isEmpty()) {
//			int id1 = Integer.parseInt(id);
//			if (!name.isEmpty() || !address.isEmpty() || !password.isEmpty()) {
//				return dao.updateemp(name, address, password, id1);
//			}
//		}
//		return false;
//	}

}
