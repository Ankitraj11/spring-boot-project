package com.te.empwebapp.dao;

import java.util.List;

import com.te.empwebapp.bean.EmployeeDetails;

public interface EmployeeDao {
	EmployeeDetails authenticate(int id, String name);

	boolean addData(EmployeeDetails details);

	boolean deleteData(int id);
	EmployeeDetails showData(int id);
	List<EmployeeDetails> showDataAll();

	EmployeeDetails updateemp(EmployeeDetails details,EmployeeDetails details2);


}
