package com.te.empwebapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.te.empwebapp.bean.EmployeeDetails;

@Repository
public class EmployeeDetailsImpl implements EmployeeDao {

	@Override
	public EmployeeDetails authenticate(int id, String name) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
		EntityManager manager = factory.createEntityManager();

		EmployeeDetails employee = manager.find(EmployeeDetails.class, id);
		if (employee != null) {
			if (employee.getPassword().equals(name)) {
				return employee;
			}
		}
		return null;
	}

	@Override
	public boolean addData(EmployeeDetails details) {
		EntityTransaction transaction = null;
		boolean result = false;
		try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
			EntityManager manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			manager.persist(details);
			transaction.commit();
			result = true;

		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public boolean deleteData(int id) {
		EntityTransaction transaction = null;
		boolean result = false;
		try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
			EntityManager manager = factory.createEntityManager();
			transaction = manager.getTransaction();

			transaction.begin();
			EmployeeDetails find = manager.find(EmployeeDetails.class, id);
			manager.remove(find);
			transaction.commit();
			result = true;

		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public EmployeeDetails showData(int id) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
		EntityManager manager = factory.createEntityManager();
		EmployeeDetails details = manager.find(EmployeeDetails.class, id);
		if (details != null) {
			return details;
		}

		return null;
	}

	@Override
	public List<EmployeeDetails> showDataAll() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
		EntityManager manager = factory.createEntityManager();
		String query = "from EmployeeDetails";
		Query alldata = manager.createQuery(query);
	    List<EmployeeDetails> data = alldata.getResultList();
		if (data != null) {
			return data;
		}

		return null;
	}

	
	@Override
	public EmployeeDetails updateemp(EmployeeDetails details,EmployeeDetails details2) {
		EntityTransaction transaction = null;
		try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("emp");
			EntityManager manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			EmployeeDetails details3 = manager.find(EmployeeDetails.class, details2.getId());
			if(details3!=null) {
			
				details3.setName(details.getName());
				details3.setAddress(details.getAddress());
				details3.setPassword(details.getPassword());
				
				transaction.begin();
				manager.persist(details3);
				transaction.commit();
				return details3;
			}else return null;


		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}

		return null;
	}

}
