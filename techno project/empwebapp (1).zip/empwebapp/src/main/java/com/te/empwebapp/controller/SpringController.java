package com.te.empwebapp.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.te.empwebapp.bean.EmployeeDetails;
import com.te.empwebapp.service.EmployeeService;

@Controller
public class SpringController {
	@Autowired
	private EmployeeService service;

	@GetMapping("/login")
	public String login() {
		return "loginform";
	}

	@PostMapping("/home")
	public String home(int id, String password, ModelMap map, HttpServletRequest request) {

		EmployeeDetails details = service.authenticate(id, password);
		HttpSession session = request.getSession();
		session.setAttribute("loggedIn", details);
		if (details != null) {
			map.addAttribute("data", details.getName());
			return "welcome";
		} else {
			map.addAttribute("err", "Invalid Details");
			return "loginform";
		}

	}

	@GetMapping("/signup")
	public String signup() {
		return "signup";
	}

	@PostMapping("/Home")
	public String signup(EmployeeDetails details, ModelMap map, HttpServletRequest request) {

		HttpSession session = request.getSession();
		session.setAttribute("loggedIn", details);

		if (service.addData(details)) {
			map.addAttribute("data", details.getName());
			return "welcome";
		} else {
			map.addAttribute("err", "Please Enter Correct Details ");
			return "signup";
		}

	}

	@GetMapping("/add")
	public String addForm(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details2,
			ModelMap map) {
		if (details2 != null) {
			return "addDetails";
		} else {
			map.addAttribute("err", "please login first!");
			return "loginform";

		}

	}

	@PostMapping("/add")
	public String addData(EmployeeDetails details, ModelMap map,
			@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details2) {
		if (details2 != null) {
			if (service.addData(details)) {
				map.addAttribute("msg", "Data Inserted Successfully!");
				return "addDetails";
			} else {
				map.addAttribute("err", "Something Went Wrong!");
				return "addDetails";
			}
		} else {
			map.addAttribute("err", "please login first!");
			return "loginform";

		}

	}

	@GetMapping("/delete")
	public String deleteData(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details,
			ModelMap map) {

		if (details != null) {
			return "deleteForm";
		} else {
			map.addAttribute("err", "please login first!");
			return "loginform";
		}
	}

	@PostMapping("/delete")
	public String deleteData(int id, @SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details,
			ModelMap map) {

		if (details != null) {
			if (service.deleteData(id)) {
				map.addAttribute("msg", "data deleted successfully!");
			} else {
				map.addAttribute("msg", "data not found!");
			}
			return "deleteForm";

		} else {
			map.addAttribute("err", "please login first!");
			return "loginform";
		}
	}

	@GetMapping("/showdata")
	public String showData(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details,
			ModelMap map) {
		if (details != null) {
			return "showdata";
		} else {
			map.addAttribute("err", "please login first!");
			return "loginform";
		}
	}

	@PostMapping("/showdata")
	public String showData(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details, ModelMap map,
			int id) {
		if (details != null) {
			EmployeeDetails details2 = service.showData(id);
			if (details2 != null) {
				map.addAttribute("data", details2);
			} else {
				map.addAttribute("err", "Data not found for id:" + id);
			}
			return "showdata";
		} else {
			map.addAttribute("err", "please login first!");
			return "loginform";
		}
	}

	@GetMapping("/showall")
	public String showDataAll(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details,
			ModelMap map) {
		if (details != null) {
			List<EmployeeDetails> data = service.showDataAll();
			if (data != null) {
				map.addAttribute("data", data);
			} else {
				map.addAttribute("err", "Data not found ");
			}
			return "showall";
		} else {
			map.addAttribute("err", "please login first!");
			return "loginform";
		}
	}

	@GetMapping("/update")
	public String update(@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details, ModelMap map) {
		if (details != null) {
			map.addAttribute("data", details.getId());
			return "update";
		} else {
			map.addAttribute("err", "please login first!");
			return "loginform";
		}
	}

	@PostMapping("/updateemp")
	public String updateemp(EmployeeDetails details2,@SessionAttribute(name = "loggedIn", required = false) EmployeeDetails details, ModelMap map) {
		if (details != null) {

			EmployeeDetails details3 = service.updateemp(details2,details);
		if (details3!=null) {
			map.addAttribute("msg", "data Updated Successfully");
			map.addAttribute("data", details.getId());

		} else {
			map.addAttribute("msg", "something went wrongs");
		}
		return "update";
	}else

	{
		map.addAttribute("err", "please login first!");
		return "loginform";
	}
	}



	@GetMapping("/logout")
	public String logout(ModelMap map, HttpSession session) {
		session.invalidate();
		map.addAttribute("err", "Logged Out Successfully");
		return "loginform";
	}

}
