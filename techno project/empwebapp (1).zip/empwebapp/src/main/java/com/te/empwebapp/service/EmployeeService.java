package com.te.empwebapp.service;

import java.util.List;

import com.te.empwebapp.bean.EmployeeDetails;

public interface EmployeeService {
	EmployeeDetails authenticate(int id,String name);
	boolean addData(EmployeeDetails details);
	boolean deleteData(int id);
	EmployeeDetails showData(int id);
	List<EmployeeDetails> showDataAll();
	EmployeeDetails updateemp(EmployeeDetails details,EmployeeDetails details2);
//	boolean updateallemp(String name,String address,String password,String id);

}
