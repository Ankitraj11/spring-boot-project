package com.technoelevate.mockitodemo.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class UserDTOTest {

	private ObjectMapper mapper = new ObjectMapper();

	String json = "{\"id\":1,\"firstName\":null,\"lastName\":null,\"age\":0,\"email\":null,\"address\":null}";

	@Test
	void userDToTest() throws JsonProcessingException {
//		UserDTO data = new UserDTO(1, null, null, 0, null, null);
//		System.out.println(mapper.writeValueAsString(data));

		UserDTO readValue = mapper.readValue(json, UserDTO.class);
		String writeValueAsString = mapper.writeValueAsString(readValue);
		
		assertEquals(json, writeValueAsString);
	}

}
