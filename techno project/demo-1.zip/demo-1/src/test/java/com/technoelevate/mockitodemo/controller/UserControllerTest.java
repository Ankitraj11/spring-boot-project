package com.technoelevate.mockitodemo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.technoelevate.mockitodemo.dto.UserDTO;
import com.technoelevate.mockitodemo.response.UserResponse;
import com.technoelevate.mockitodemo.service.UserService;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class UserControllerTest {

	@Autowired
	private WebApplicationContext context;

	private MockMvc mockMvc;

	@MockBean
	private UserService service;

	private ObjectMapper mapper = new ObjectMapper();

	@BeforeEach
	void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}

	@Test
	void addUserTest() throws JsonProcessingException, UnsupportedEncodingException, Exception {
		UserDTO data = new UserDTO(1, "abc", "abc", 27, null, null);
		when(service.addUser(data)).thenReturn(data);
		String contentAsString = mockMvc.perform(post("/addUser").content(mapper.writeValueAsString(data))
				.contentType(MediaType.APPLICATION_JSON_VALUE).accept(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		UserResponse readValue = mapper.readValue(contentAsString, UserResponse.class);
		assertEquals("User added successfully. ", readValue.getMessage());
	}

}
