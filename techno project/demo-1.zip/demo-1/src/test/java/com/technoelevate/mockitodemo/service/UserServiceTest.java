package com.technoelevate.mockitodemo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.technoelevate.mockitodemo.dto.UserDTO;
import com.technoelevate.mockitodemo.repository.UserRepository;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class UserServiceTest {
	
	@MockBean
	private UserRepository repository;
	
	private ObjectMapper mapper = new ObjectMapper();
	
	@Test
	void addUserTest() throws JsonProcessingException {
		UserDTO data = new UserDTO();
		data.setId(1);
		data.setAge(25);
		
		repository.save(data);
		Optional<UserDTO> findById = repository.findById(1);
		
		String writeValueAsString = mapper.writeValueAsString(findById);
		UserDTO readValue = mapper.readValue(writeValueAsString, UserDTO.class);
		
		assertEquals(25, readValue.getAge());
	}

}
