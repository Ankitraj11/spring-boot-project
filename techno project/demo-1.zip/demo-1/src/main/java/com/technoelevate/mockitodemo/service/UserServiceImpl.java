package com.technoelevate.mockitodemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.mockitodemo.dto.UserDTO;
import com.technoelevate.mockitodemo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository repository;

	@Override
	public UserDTO addUser(UserDTO data) {
		return repository.save(data);
	}

}
