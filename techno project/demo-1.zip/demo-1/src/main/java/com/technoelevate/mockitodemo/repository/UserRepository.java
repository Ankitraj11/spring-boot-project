package com.technoelevate.mockitodemo.repository;

import org.springframework.data.repository.CrudRepository;

import com.technoelevate.mockitodemo.dto.UserDTO;

public interface UserRepository extends CrudRepository<UserDTO, Integer> {

}
