package com.technoelevate.mockitodemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.mockitodemo.dto.UserDTO;
import com.technoelevate.mockitodemo.response.UserResponse;
import com.technoelevate.mockitodemo.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	private UserService service;

	@PostMapping("/addUser")
	public ResponseEntity<UserResponse> addUser(@RequestBody UserDTO data) {
		if (data != null) {
			service.addUser(data);
			return new ResponseEntity<>(new UserResponse(false, "User added successfully. ", data), HttpStatus.OK);
		}
		return new ResponseEntity<>(new UserResponse(true, "User not added. ", data), HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
