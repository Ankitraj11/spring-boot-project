package com.technoelevate.mockitodemo.service;

import com.technoelevate.mockitodemo.dto.UserDTO;


public interface UserService {

	UserDTO addUser(UserDTO data);

}
