package com.technoelevate.mockitodemo.response;

import com.technoelevate.mockitodemo.dto.UserDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {

	private boolean error;

	private String message;

	private UserDTO data;

}
