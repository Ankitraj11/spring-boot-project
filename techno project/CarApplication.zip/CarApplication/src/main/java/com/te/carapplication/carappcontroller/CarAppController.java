package com.te.carapplication.carappcontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.carapplication.carService.UserService;
import com.te.carapplication.dto.CarApplicationInfo;
import com.te.carapplication.dto.UserApp;
import com.te.carapplication.jwt.authenticate.AuthenticateRequest;
import com.te.carapplication.jwt.authenticate.AuthenticateResponse;
import com.te.carapplication.jwt.authenticate.CarResponse;
import com.te.carapplication.jwt.util.JwtUtil;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/user")
public class CarAppController {
	@Autowired
	private UserService userService;
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private UserDetailsService userDetailsService;
	@Autowired
	private JwtUtil jwtUtil;

	@PostMapping("/login")
	public ResponseEntity<?> loginAuthenticationToken(@RequestBody AuthenticateRequest authenticateRequest) {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
					authenticateRequest.getUsername(), authenticateRequest.getPassword()));
		} catch (AuthenticationException e) {
			return ResponseEntity.ok(new AuthenticateResponse("Username and password is Invalid", true, null));
		}
		UserDetails details = userDetailsService.loadUserByUsername(authenticateRequest.getUsername());
		String jwt = jwtUtil.generateToken(details);
		return ResponseEntity.ok(new AuthenticateResponse("Authentication success", false, jwt));
	}

	@PostMapping("/signup")
	public ResponseEntity<?> singupAuthentication(@RequestBody UserApp userApp) {

		UserApp signup = userService.saveData(userApp);
		if (signup != null) {
			authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(signup.getUsername(), signup.getPassword()));
			UserDetails details = userDetailsService.loadUserByUsername(signup.getUsername());
			String jwt = jwtUtil.generateToken(details);
			return ResponseEntity.ok(new AuthenticateResponse("Signup Succes", false, null));
		} else {
			return ResponseEntity.ok(new AuthenticateResponse("username already exists", true, null));
		}

	}

	@PostMapping("/add")
	public ResponseEntity<?> addData(@RequestBody CarApplicationInfo applicationInfo, HttpServletRequest request) {
		try {
			userService.addData(applicationInfo, request);
			return ResponseEntity.ok(new CarResponse("Added succesfully", false, null));
		} catch (Exception e) {
			return ResponseEntity.ok(new CarResponse("Something went wrong Please try Again!", true, null));
		}
	}

	@PutMapping("/modify/{carId}")
	public ResponseEntity<?> modifyData(@RequestBody CarApplicationInfo applicationInfo, @PathVariable int carId,
			HttpServletRequest request) {
		try {
			applicationInfo.setCarId(carId);
			userService.modify(carId, applicationInfo, request);
			return ResponseEntity.ok(new CarResponse("Updated successfully", false, null));
		} catch (Exception e) {
			return ResponseEntity.ok(new CarResponse("Something went wrong please try Again!", true, null));
		}
	}

	@GetMapping("/search/{carId}")
	public ResponseEntity<?> search(@PathVariable int carId) {
		CarApplicationInfo applicationInfo = userService.search(carId);
		if (applicationInfo != null) {
			return new ResponseEntity<CarApplicationInfo>(applicationInfo, HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("data not found for id:" + carId, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/delete/{carId}")
	public ResponseEntity<?> delete(@PathVariable int carId) {
		try {
			userService.delete(carId);
			return ResponseEntity.ok(new CarResponse("deleted succesfully", false, null));
		} catch (Exception e) {
			return ResponseEntity.ok(new CarResponse("something went wrong", true, null));
		}
	}

	@GetMapping("/details")
	public ResponseEntity<?> getAllDetails() {
		try {
			List<CarApplicationInfo> carApplicationInfos = userService.allDetails();
			return ResponseEntity.ok(new CarResponse("All details has been fetched",false, carApplicationInfos));
		} catch (Exception e) {
			return ResponseEntity.ok(new CarResponse("Something went wrong please try Again", true, null));
		}

	}

}
