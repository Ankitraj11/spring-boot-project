package com.te.carapplication.dao;

import org.springframework.data.repository.CrudRepository;
import com.te.carapplication.dto.CarApplicationInfo;

public interface CarDao extends CrudRepository<CarApplicationInfo, Integer> {

	public CarApplicationInfo findByCarId(int carId);
	
	public CarApplicationInfo findByName(String name);
	
	public CarApplicationInfo findByFuelType(String fuelType);
	
	public CarApplicationInfo findByCompanyName(String companyName);
}
