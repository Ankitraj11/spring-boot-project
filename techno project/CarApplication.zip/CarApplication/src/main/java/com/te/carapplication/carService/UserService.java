package com.te.carapplication.carService;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.te.carapplication.dto.CarApplicationInfo;
import com.te.carapplication.dto.UserApp;

public interface UserService {
	
	UserApp saveData(UserApp userApp);

	CarApplicationInfo addData(CarApplicationInfo applicationInfo, HttpServletRequest request);
	
	CarApplicationInfo modify(int carId,CarApplicationInfo applicationInfo, HttpServletRequest request);

	CarApplicationInfo search(int carId);
	
	boolean delete(int carId);
	
	List<CarApplicationInfo> allDetails();

}
