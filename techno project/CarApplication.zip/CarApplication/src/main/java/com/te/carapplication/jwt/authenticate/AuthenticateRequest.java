package com.te.carapplication.jwt.authenticate;

import java.util.List;

import com.te.carapplication.dto.CarApplicationInfo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthenticateRequest {
	
	private String username;
	private String password;
}
