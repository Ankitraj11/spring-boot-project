package com.te.carapplication.jwt.authenticate;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.te.carapplication.dto.CarApplicationInfo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CarResponse {
	
	private String message;
	private boolean error;
	private List<CarApplicationInfo> getAllCars;

}
