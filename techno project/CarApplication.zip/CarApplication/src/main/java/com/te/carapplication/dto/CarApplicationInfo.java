package com.te.carapplication.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "CarDetails")
public class CarApplicationInfo implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int carId;
	@Column
	private String name;
	@Column
	private String companyName;
	@Column
	private String fuelType;
	@Column
	private String steering;
	@Column
	private String breakSystem;
	@Column
	private double showroomPrice;
	@Column
	private double onRoadPrice;
	@Column
	private String imgURL;
	@Column
	private double mileage;
	@Column
	private int seatingCapacity;
	@Column
	private int engineCapacity;
	@Column
	private String gearType;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_fk", referencedColumnName = "username")
	private UserApp userApp;

}
