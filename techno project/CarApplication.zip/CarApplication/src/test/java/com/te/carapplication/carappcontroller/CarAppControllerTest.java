package com.te.carapplication.carappcontroller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.te.carapplication.carService.UserService;
import com.te.carapplication.dto.CarApplicationInfo;
import com.te.carapplication.jwt.authenticate.CarResponse;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
class CarAppControllerTest {

//	@MockBean
//	private UserApp userApp;

	@MockBean
	private UserService userService;

	private MockMvc mockMvc;

	@MockBean
	private UserDetailsService userDetailsService;

	@Autowired
	private WebApplicationContext applicationContext;

	private ObjectMapper objectMapper = new ObjectMapper();

	@BeforeEach
	void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(applicationContext).build();
	}

	@Test
	void testLoginAuthenticationToken() {
		fail("Not yet implemented");
	}

	@Test
	void testSingupAuthentication() {
		fail("Not yet implemented");
	}

	@Test
	void testAddData() throws JsonProcessingException, UnsupportedEncodingException, Exception {
//		fail("Not yet implemented");
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", request);
		CarApplicationInfo applicationInfo= new CarApplicationInfo();
		applicationInfo.setName("Hyundai-i20");
		applicationInfo.setCompanyName("Hyundai");
		applicationInfo.setFuelType("Petrol");
		applicationInfo.setSeatingCapacity(4);
		applicationInfo.setBreakSystem("");
		applicationInfo.setGearType("");
		applicationInfo.setEngineCapacity(2000);
		applicationInfo.setMileage(0);
		applicationInfo.setOnRoadPrice(402000.80);
		applicationInfo.setShowroomPrice(4500020.20);
		applicationInfo.setImgURL(null);
		when(userService.addData(applicationInfo, request)).thenReturn(applicationInfo);
		
		String content = mockMvc.perform(post("/user/add").contentType(MediaType.APPLICATION_JSON_VALUE).content(objectMapper.writeValueAsString(applicationInfo)).accept(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		CarResponse carResponse = objectMapper.readValue(content, CarResponse.class);
		System.out.println("result"+content);
		assertEquals("Added succesfully", carResponse.getMessage());
	}

	@Test
	void testModifyData() throws JsonProcessingException, UnsupportedEncodingException, Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGV4cCIsImV4cCI6MTY0NjY3MjE0MywiaWF0IjoxNjQ2NjM2MTQzfQ.uG4JDfTsKPYw4xUvir7A2ibaupq2yxacWQoIll7B2KI");
		CarApplicationInfo applicationInfo= new CarApplicationInfo();
		applicationInfo.setName("Hyundai-i20");
		applicationInfo.setCompanyName("Hyundai");
		applicationInfo.setFuelType("Petrol");
		applicationInfo.setSeatingCapacity(4);
		applicationInfo.setBreakSystem("drum");
		applicationInfo.setGearType("Torque");
		applicationInfo.setEngineCapacity(2000);
		applicationInfo.setMileage(19.8);
		applicationInfo.setOnRoadPrice(402000.80);
		applicationInfo.setShowroomPrice(4500020.20);
		applicationInfo.setImgURL(null);
		applicationInfo.setSteering("circle");
		applicationInfo.setCarId(4);
		when(userService.modify(4,applicationInfo, request)).thenReturn(applicationInfo);
		
		String content = mockMvc.perform(put("/user/modify/4").contentType(MediaType.APPLICATION_JSON_VALUE).content(objectMapper.writeValueAsString(applicationInfo)).accept(MediaType.APPLICATION_JSON_VALUE)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		CarResponse carResponse = objectMapper.readValue(content, CarResponse.class);
		System.out.println("result"+content);
		assertEquals("Updated successfully", carResponse.getMessage());
		
	}

	@Test
	void testSearch() {
		fail("Not yet implemented");
	}

	@Test
	void testDelete() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAllDetails() {
		fail("Not yet implemented");
	}

}
