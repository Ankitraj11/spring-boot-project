package com.te.carapplication.carService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CarServiceImplTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testLoadUserByUsername() {
		fail("Not yet implemented");
	}

	@Test
	void testAllDetails() {
		fail("Not yet implemented");
	}

	@Test
	void testAddData() {
		fail("Not yet implemented");
	}

	@Test
	void testModify() {
		fail("Not yet implemented");
	}

	@Test
	void testSearch() {
		fail("Not yet implemented");
	}

	@Test
	void testDelete() {
		fail("Not yet implemented");
	}

	@Test
	void testSaveData() {
		fail("Not yet implemented");
	}

}
