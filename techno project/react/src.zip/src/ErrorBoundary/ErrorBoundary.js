import React, { Component } from 'react'

export class ErrorBoundary extends Component {
    state ={
        hasError:false
    };
    static getDeriveStateFromError(error){
        console.log("getDeriveStateFromError");
        return {hasError: true}
    }
    componentDidCatch(info,error){
        console.log("componentdidcatch");
        console.log("err", error);
        console.log("info",info);
    }
  render() {
    
        if(this.state.error){
            return <fallbackUI />;
        }else{
            return this.props.children;
        }
     
  }
}

export default ErrorBoundary