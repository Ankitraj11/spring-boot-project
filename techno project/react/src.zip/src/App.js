import logo from './logo.svg';
import './App.css';
import ErrorBoundary from './ErrorBoundary/ErrorBoundary';
import Person from './Components/Person';

let PersonDerailsComponent=React.lazy(()=>import("./Components/PersonDetails"))
function App() {
  const [showApp, setshowApp] = useState(false)
  return (
    <div className="App">
     {/* <ErrorBoundary>
       <Person />
     </ErrorBoundary> */}
     <buttun onClick=(()=>{
       setshowApp(true);
     })>show app <buttun>
    </div>
  );
}

export default App;
