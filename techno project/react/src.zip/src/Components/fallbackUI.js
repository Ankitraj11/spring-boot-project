import React from 'react'

function fallbackUI() {
  return (
    <div>
        <img src='https://media.istockphoto.com/photos/image-of-autumn-time-change-fall-back-concept-picture-id843386234?k=20&m=843386234&s=612x612&w=0&h=xc7ui7iyrG6ix51ylN-3Rw8SIr_EpMDOKwoFMxasPRY=' alt='something went wrong'/>
    </div>
  )
}

export default fallbackUI