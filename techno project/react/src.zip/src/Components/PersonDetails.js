import React from 'react'

function PersonDetails() {
  return (
    <div>person deatils are present in header</div>
  )
}

export default PersonDetails