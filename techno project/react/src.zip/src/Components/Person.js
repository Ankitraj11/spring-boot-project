import React from 'react'

function Person() {
  return (
    <div>
        <h1>i am a good perons</h1>
        {props.data.slice()}
    </div>
  )
}

export default Person