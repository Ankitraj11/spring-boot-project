import React from 'react'
import useCounter from '../Hooks/UseCounter'
function CounterOne() {
    const [count,increment,decrement,reset]=useCounter(0,20);
  return (
    <div>
   <h2>Counter one:{count}</h2>
   <button onClick={()=>{increment(30)}}>incriment</button>
   <button onClick={()=>{decrement()}}>decrement</button>
   <button onClick={()=>{reset()}}>reset</button>
    </div>
  )
}

export default CounterOne;