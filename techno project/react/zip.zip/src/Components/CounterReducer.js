
import React, { useReducer } from 'react'

let initialValue = { firstCounter:0,secondCounter:0};
let reducer =(prevState,action)=>{
    switch (action.type) {
       case "increment":
           return  {
               ...prevState,
               firstCounter:prevState.firstCounter + 1
           };
           case "decrement":
           return {
            ...prevState,
            firstCounter:prevState.firstCounter - 1
           } ;
           case "reset":
               return {
                   ...prevState,
                   firstCounter:initialValue.firstCounter
               };
               case "increment1":
                return  {
                    ...prevState,
                    secondCounter:prevState.secondCounter + 1
                };
                case "decrement1":
                return {
                 ...prevState,
                 secondCounter:prevState.secondCounter - 1
                } ;
                case "reset1":
                    return {
                        ...prevState,
                        secondCounter:initialValue.secondCounter
                    };
         
        default:
         return prevState;
    }
}




function CounterReducer() {
    const [state, dispatch] = useReducer(reducer,initialValue)
  return (
    <div>
<h2>counter :{state.firstCounter}</h2>
<button onClick={()=>{
    dispatch({type:"increment"})
}}>increment</button>
<button onClick={()=>{
    dispatch({type:"decrement"})
}}>decrement</button>
<button onClick={()=>{
    dispatch({type:"reset"})
}}>reset</button>
<br></br>
<h2>counter2 :{state.secondCounter}</h2>
<button onClick={()=>{
    dispatch({type:"increment1"})
}}>increment</button>
<button onClick={()=>{
    dispatch({type:"decrement1"})
}}>decrement</button>
<button onClick={()=>{
    dispatch({type:"reset1"})
}}>reset</button>
    </div>
  )
}

export default CounterReducer
