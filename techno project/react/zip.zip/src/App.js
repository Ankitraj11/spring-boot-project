import logo from './logo.svg';
import './App.css';
import CounterOne from './Components/CounterOne';
import CounterTwo from './Components/CounterTwo';
import CounterReducer from './Components/CounterReducer';

function App() {
  return (
    <div className="App">
    {/* <CounterOne />
    <CounterTwo /> */}
    

    <CounterReducer />
         </div>
  );
}

export default App;
