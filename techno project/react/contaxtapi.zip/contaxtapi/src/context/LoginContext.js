import { createContext } from "react";

const LoginContext = createContext()
let LoginProvider = LoginContext.Provider
let LoginConsumer = LoginContext.Consumer

export default LoginContext
export {LoginProvider,LoginConsumer}