import React from 'react'
import { UserConsumer } from '../context/Context'

function ComponentC(props) {
  return (
    <div>
        <UserConsumer>
            {(userData)=>{
                return (
                    <h2 style={{color:"red"}}>uname from Context:</h2>
                )
            }}
        </UserConsumer>
        <h1 style={{color:"blueviolet"}}>Uname from props drilling : {props.uname}</h1>
    </div>
  )
}

export default ComponentC