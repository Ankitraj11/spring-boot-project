import React, { useContext } from 'react'
import LoginContext from '../context/LoginContext'

function ComponentD() {

    let Context = useContext(LoginContext)
    console.log("context",Context);

    let sendData = ()=>{
        Context.getDatatFromD("i am sending data from componentD");
    }
    
  return (
    <div>
<button onClick={sendData}>send data to parent</button>
    </div>
  )
}

export default ComponentD