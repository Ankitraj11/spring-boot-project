import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import ComponentA from './component/ComponentA';
import { UserProvider } from './context/Context';
import { LoginProvider } from './context/LoginContext';
import ComponentD from './component/ComponentD';

function App() {
  const [uname, setuname] = useState("Ajeet");

  // LoginContext.js
  let getDatatFromD = (data)=>{
    console.log("Data in parent from came from D",data);
  }
const [loginData, setloginData] = useState({
  loginUser:"Aishwarya",
  getDatatFromD:getDatatFromD
  
})

  return (
    <div className="App">
      <UserProvider  value = {uname}>
        <ComponentA uname = {uname}/>
      </UserProvider>
      <LoginProvider value={loginData}>
        <ComponentD />
      </LoginProvider>
    </div>
  );
}

export default App;
