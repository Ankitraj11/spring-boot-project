import { useState } from 'react';
import './App.css';
import UserForm from './components/UserForm';
import UserTable from './components/UserTable';
function App() {
  const [userData, setuserData] = useState([])
  
console.log('userData from parent',userData);

  let getDataFromUserForm=(data)=>{
    // console.log("data from parent",data);
    let userDataCopy = [...userData]
    userDataCopy.push(data)
    setuserData(userDataCopy)
  }
  return (
    <div className="App">
    
      <h1>React form </h1>
      <UserForm getDataFromUserForm={getDataFromUserForm} />
      <UserTable userData={userData} />
    </div>
  );
}

export default App;
