import React, { useState } from "react";

function UserForm(props) {

    const [userData, setuserData] = useState({
        email:"",
        password:""
    })
    // console.log('userData',userData);

    let updateUserData=(event)=>{
        setuserData({
            ...userData,
            [event.target.name]:event.target.value  
        }) 
    }
    let saveData=(e)=>{
        //do all the validation and then send the data to parent
        e.preventDefault()
        props.getDataFromUserForm(userData)
        setuserData({
            email:"",
            password:""
        })
    }

  return (
    <div>
      <form className="container">
        <div className="mb-3">
          <input
          name="email"
          placeholder="Enter email"
            // type="email"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            value={userData.email}
            onChange={(event)=>{updateUserData(event)}}
          />
        </div>
        <div className="mb-3">
          <input
          name="password"
            placeholder="Enter Password"
            type="password"
            className="form-control"
            id="exampleInputPassword1"
            value={userData.password}
            onChange={(event)=>{updateUserData(event)}}
          />
        </div>

        <button type="submit" className="btn btn-primary" onClick={(e)=>{saveData(e)}}>
          Submit
        </button>
      </form>
    </div>
  );
}

export default UserForm;
