import React from 'react'

function User(props) {
  return (
    <div>
        <h1>{props.val} </h1>
    </div>
  )
}

export default User