import React from 'react'
import User from './User'

function UserTable(props) {
  return (
    <div>
        {
            props.userData.map((val,idx)=>{
                return <div>
                    <p>{val.email}</p>
                    <p>{val.password}</p>
                    </div>
            })
        }
    </div>
  )
}

export default UserTable