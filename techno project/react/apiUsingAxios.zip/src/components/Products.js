import axios from "axios";
import React, { useEffect, useState } from "react";
import { Table } from "react-bootstrap";
import HTTP from "../axiosConfig";
import AddProduct from "./AddProduct";
import EditProduct from "./EditProduct";

function Products() {
  const [products, setproducts] = useState([]);
  const [showAddModal, setshowAddModal] = useState(false);
  const [selectedProduct, setselectedProduct] = useState({});
  const [showEditModal, setshowEditModal] = useState(false);

  console.log("selectedProduct", selectedProduct);
  useEffect(() => {
    fetchProducts();
  }, []);

  let fetchProducts = async () => {
    try {
      let res = await HTTP.get("api/products");
      // console.log(res.data.products);
      if (res.data.error) {
        let errMsg = res.data.message;
      } else {
        let fetchedProducts = res.data.products;
        setproducts(fetchedProducts);
      }
    } catch (err) {
      console.log(err);
    }
  };

  let hideAddModal = () => {
    setshowAddModal(false);
  };

  //selected product
  let updateProduct = (product) => {
    setshowEditModal(true);
    setselectedProduct(product);
  };

  let hideEditModal = () => {
    setshowEditModal(false);
  };

  let deleteProduct = async (id) => {
    try {
      let res = await axios.delete(
        `https://ty-shop.herokuapp.com/api/products/${id}`
      );
      // console.log(res.data.products);
      if (res.data.error) {
        alert(res.data.message);
      } else {
        alert(res.data.message);
        fetchProducts();
      }
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <div>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Product Price</th>
            <th>Product Description</th>
            <th>Product Image</th>
            <th>
              <button
                className="btn btn-warning"
                onClick={() => {
                  setshowAddModal(true);
                }}
              >
                ADD
              </button>
            </th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => {
            return (
              <tr key={product._id}>
                <td>{product._id}</td>
                <td>{product.productName}</td>
                <td>{product.productPrice}</td>
                <td>{product.productDescription}</td>
                <td>
                  <img
                    width="180px"
                    height="150px"
                    src={product.productImageURL}
                    alt={product.productName}
                  />
                </td>
                <td>
                  <button
                    className="btn btn-primary m-2"
                    onClick={() => {
                      updateProduct(product);
                    }}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-danger m-2"
                    onClick={() => {
                      deleteProduct(product._id);
                    }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </Table>

      <AddProduct
        showAddModal={showAddModal}
        hideAddModal={hideAddModal}
        fetchProducts={fetchProducts}
      />

      <EditProduct 
        selectedProduct={selectedProduct}
        showEditModal={showEditModal}
        hideEditModal={hideEditModal}
        fetchProducts={fetchProducts}
      />
    </div>
  );
}

export default Products;
