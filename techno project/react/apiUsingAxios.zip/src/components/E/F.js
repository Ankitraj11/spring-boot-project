import React from 'react'

function F() {
  return (
    <div>F component</div>
  )
}

export default F