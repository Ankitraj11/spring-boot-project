import React, { Component } from 'react'

export class E extends Component {
    state={
        hasError:true
    }
  render() {
    static getDer
    return (
      <div>E</div>
    )
  }
}

export default E