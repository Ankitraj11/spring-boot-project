import axios from "axios";
import React, { useEffect, useState } from "react";
import JSONHTTP from "../axiosConfig";

function Users() {
  const [users, setusers] = useState([]);
  const [error, seterror] = useState();
  const [loading, setloading] = useState(false);

  //   console.log(users);
  console.log("users state", users);
  useEffect(() => {
    fetchUsers();
  }, []);

  let fetchUsers = async () => {
    try {
      setloading(true);
      let res = await JSONHTTP.get('comments');
      setloading(false);
      //console.log(res.data);
      setusers(res.data);
    } catch (err) {
      console.log(err);
      seterror(err);
      setloading(false);
    }
  };

  if (!loading) {
    if (error) {
      return (
        <div>
          <p style={{ color: "red" }}>{error.message}</p>
        </div>
      );
    } else {
      return (
        <div>
          {users.map((user) => {
            return <p key={user.id}>{user.username}</p>;
          })}
        </div>
      );
    }
  } else {
    return <p style={{ color: "green" }}>Loading...</p>;
  }
}

export default Users;
