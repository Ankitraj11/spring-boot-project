// import { Button } from 'bootstrap'
import axios from "axios";
import React, { useState } from "react";
import { Modal, Button } from "react-bootstrap";

function AddProduct(props) {
  const [singleProduct, setsingleProduct] = useState({
    productName: "",
    productPrice: "",
    productDescription: "",
    productImageURL: "",
  });

  let addProduct = (e) => {
    setsingleProduct({
      ...singleProduct,
      [e.target.name]: e.target.value,
    });
  };

  let saveData = async () => {
    try {
      let res = await axios.post(
        "https://ty-shop.herokuapp.com/api/products",
        singleProduct
      );
      // console.log(res.data.products);
      if (res.data.error) {
        console.log(res.data);
        alert(res.data.message);
      } else {
        alert(res.data.message);
        props.hideAddModal();
        props.fetchProducts();

        setsingleProduct({
          productName: "",
          productPrice: "",
          productDescription: "",
          productImageURL: "",
        });
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div>
      <Modal show={props.showAddModal} onHide={props.hideAddModal}>
        <Modal.Header closeButton>
          <Modal.Title>Add Product </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <input
            placeholder="Enter Product Name"
            name="productName"
            value={singleProduct.productName}
            onChange={addProduct}
          />

          <input
            placeholder="Enter productPrice "
            name="productPrice"
            value={singleProduct.productPrice}
            onChange={addProduct}
          />

          <input
            placeholder="Enter productDescription"
            name="productDescription"
            value={singleProduct.productDescription}
            onChange={addProduct}
          />

          <input
            placeholder="Enter productImageURL"
            name="productImageURL"
            value={singleProduct.productImageURL}
            onChange={addProduct}
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={props.hideAddModal}>
            Close
          </Button>
          <Button variant="primary" onClick={saveData}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default AddProduct;
