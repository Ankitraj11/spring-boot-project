import axios from "axios";
import React, { useEffect, useState } from "react";
import { Button, Modal } from "react-bootstrap";
import HTTP from "../axiosConfig";

function EditProduct(props) {
  const [singleProduct, setsingleProduct] = useState({
    productName: "",
    productPrice: "",
    productDescription: "",
    productImageURL: "",
  });

//   console.log('props.selectedProduct',props.selectedProduct);

  useEffect(() => {
    setsingleProduct(props.selectedProduct);
  }, [props.selectedProduct]);

  let updateProduct = (e) => {
    setsingleProduct({
      ...singleProduct,
      [e.target.name]: e.target.value,
    });
  };

  let saveData = async () => {
    try {
      let res = await HTTP.put(`api/products/${props.selectedProduct._id}`,
        singleProduct
      );
      // console.log(res.data.products);
      if (res.data.error) {
        alert(res.data.message);
      } else {
        alert(res.data.message);
        props.hideEditModal();
        props.fetchProducts();
      }
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <div>
      <Modal show={props.showEditModal} onHide={props.hideEditModal}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Product </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <input
            placeholder="Enter Product Name"
            name="productName"
            value={singleProduct.productName}
            onChange={updateProduct}
          />

          <input
            placeholder="Enter productPrice "
            name="productPrice"
            value={singleProduct.productPrice}
            onChange={updateProduct}
          />

          <input
            placeholder="Enter productDescription"
            name="productDescription"
            value={singleProduct.productDescription}
            onChange={updateProduct}
          />

          <input
            placeholder="Enter productImageURL"
            name="productImageURL"
            value={singleProduct.productImageURL}
            onChange={updateProduct}
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={props.hideEditModal}>
            Close
          </Button>
          <Button variant="primary" onClick={saveData}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default EditProduct;
