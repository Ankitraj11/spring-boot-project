import "./App.css";
import Users from "./components/Users";
import Products from "./components/Products";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <div className="App">
      <Products />

      {/* <Users /> */}
    </div>
  );
}

export default App;
