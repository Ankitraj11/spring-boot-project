import React from 'react'

function Home() {
    return (
        <div>
            <h1>This is home </h1>
            <img src="assets/image.jpg" width="700px" alt=""/>
        </div>
    )
}

export default Home
