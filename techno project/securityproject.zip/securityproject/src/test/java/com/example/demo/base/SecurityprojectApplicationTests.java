package com.example.demo.base;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
