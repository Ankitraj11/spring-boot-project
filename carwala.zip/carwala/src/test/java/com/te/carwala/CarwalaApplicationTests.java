package com.te.carwala;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarwalaApplicationTests {

	@Test
	void contextLoads() {
	}

}
