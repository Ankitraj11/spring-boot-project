package com.te.carwala;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.te.carwala.dao.AdminDao;
import com.te.carwala.dao.CarDao;
import com.te.carwala.dto.AdminDetails;
import com.te.carwala.dto.CarDetails;
import com.te.carwala.service.AdminService;

@SpringBootTest

public class DaoTesting {

    @Autowired
	private CarDao carDao;
	@Autowired
    private AdminDao adminDao;
	@Autowired
	private AdminService adminService;
	
	@Test
	public void testReadAll() {
		List<CarDetails> carList=(List<CarDetails>)carDao.findAll();
		assertFalse(carList.isEmpty());
	
	
   }
	@Test
	public void testSignUp() {
		
	  
		AdminDetails adminDetails=new AdminDetails();
		adminDetails.setAdminId(100);
		adminDetails.setAdminRole("ROLE_ADMIN");
		adminDetails.setUserName("niraj");
		adminDetails.setPassword("niraj");
		
		adminDao.save(adminDetails);
		assertEquals("ROLE_ADMIN", adminDetails.getAdminRole());
	    assertEquals("niraj", adminDetails.getUserName());
	    assertEquals("niraj", adminDetails.getPassword());
	    assertEquals(100, adminDetails.getAdminId());
		
	}
	@Test
	public void findByUserNameTest() {
		
	   AdminDetails details=adminDao.findByuserName("ankit");
	   assertFalse(details.equals(null));
	}
	
	
	public void findBycarNameTest() {
		
		
	}
	
	
	
	
	
	
	
	
	
	
}
