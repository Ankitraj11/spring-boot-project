package com.te.carwala;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.te.carwala.dao.AdminDao;
import com.te.carwala.dto.AdminDetails;
import com.te.carwala.service.AdminServiceImpl;

public class ServiceLayerTesting {

	@InjectMocks
	private AdminServiceImpl adminServceImpl;
	
	@Mock
	private AdminDao adminDao;
	
	@Test
	public void signUpTest() {
		
		AdminDetails adminDetails=new AdminDetails();
		adminDetails.setAdminId(100);
		adminDetails.setAdminRole("ROLE_ADMIN");
		adminDetails.setUserName("niraj");
		adminDetails.setPassword("niraj");
	
		when(adminDao.save(adminDetails)).thenReturn(adminDetails);
		AdminDetails adminDetails2=adminServceImpl.signupData(adminDetails);
		assertEquals("ROLE_ADMIN", adminDetails2.getAdminRole());
		
	}
}
