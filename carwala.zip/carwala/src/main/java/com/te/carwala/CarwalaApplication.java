package com.te.carwala;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarwalaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarwalaApplication.class, args);
	}

}
