package com.te.empwebapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.te.empwebapp.bean.EmployeeDetails;
import com.te.empwebapp.service.EmployeeService;

@Controller
public class SpringController {
	@Autowired
	private EmployeeService service;

	@GetMapping("/login")
	public String login() {
		return "loginform";
	}

	@PostMapping("/home")
	public String home(int id, String password, ModelMap map) {

		EmployeeDetails details = service.authenticate(id, password);
		
		if (details != null) {
			map.addAttribute("data", details.getName());
			return "welcome";
		}else {
			map.addAttribute("err", "Invalid Details");
			return "loginform";
		}

	}
	@GetMapping("/add")
	public String addForm() {
		return "addDetails";
		
	}
	@PostMapping("/add")
	public String addData(EmployeeDetails details,ModelMap map) {
		if(service.addData(details)) {
			map.addAttribute("msg", "Data Inserted Successfully!");
			return "addDetails";
		}
		else {
			map.addAttribute("err", "Something Went Wrong!");
			return "addDetails";
		}
		
	}
	@GetMapping("/logout")
	public String logout(ModelMap map) {
		map.addAttribute("err", "Logged Out Successfully");
		return "loginform";
	}

}
