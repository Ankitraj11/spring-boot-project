package com.te.empwebapp.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.te.empwebapp.bean.EmployeeDetails;
import com.te.empwebapp.dao.EmployeeDao;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDao dao;

	@Override
	public EmployeeDetails authenticate(int id, String name) {
		if (id<=0) {
			return null;
		}
		return dao.authenticate(id, name);
	}

	@Override
	public boolean addData(EmployeeDetails details) {
		
		return dao.addData(details);
	}

}
