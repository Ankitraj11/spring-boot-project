package com.te.empwebapp.dao;

import com.te.empwebapp.bean.EmployeeDetails;

public interface EmployeeDao {
	EmployeeDetails authenticate(int id,String name);
	
	boolean addData(EmployeeDetails details);

}
