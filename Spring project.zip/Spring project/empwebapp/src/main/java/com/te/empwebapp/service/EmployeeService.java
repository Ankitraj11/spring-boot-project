package com.te.empwebapp.service;

import com.te.empwebapp.bean.EmployeeDetails;

public interface EmployeeService {
	EmployeeDetails authenticate(int id,String name);
	boolean addData(EmployeeDetails details);

}
